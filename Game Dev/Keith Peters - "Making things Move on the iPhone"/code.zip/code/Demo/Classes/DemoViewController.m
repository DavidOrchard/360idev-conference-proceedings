//
//  DemoViewController.m
//  Demo
//
//  Created by Keith A Peters on 2/28/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import "DemoViewController.h"

@implementation DemoViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	x = 50.0;
	y = 50.0;
	vx = 1.0;
	vy = 1.0;
	dragging = NO;
	bounce = -0.5;
	gravity = CGPointZero;
	[[UIAccelerometer sharedAccelerometer] setDelegate:self];
	ball = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ball.png"]];
	[self.view addSubview:ball];
	[NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}

- (void)onTimer
{
	if(!dragging)
	{
		ball.center = CGPointMake(x, y);
		x += vx;
		y += vy;
		vx += gravity.x;
		vy += gravity.y;
		if(x > 300)
		{
			x = 300;
			vx *= bounce;
		}
		else if(x < 20)
		{
			x = 20;
			vx *= bounce;
		}
		if(y > 440)
		{
			y = 440;
			vy *= bounce;
		}
		else if(y < 20)
		{
			y = 20;
			vy *= bounce;
		}
	}
}

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
	gravity = CGPointMake(acceleration.x, -acceleration.y);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	CGPoint point = [touch locationInView:self.view];
	float dx = point.x - x;
	float dy = point.y - y;
	float dist = sqrt(dx * dx + dy * dy);
	if(dist < 20)
	{
		dragging = YES;
		x = point.x;
		y = point.y;
		vx = 0;
		vy = 0;
	}
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(dragging)
	{
		UITouch *touch = [touches anyObject];
		CGPoint point = [touch locationInView:self.view];
		vx = point.x - x;
		vy = point.y - y;
		x = point.x;
		y = point.y;
		ball.center = point;
	}
}	

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	dragging = NO;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[ball release];
    [super dealloc];
}

@end
