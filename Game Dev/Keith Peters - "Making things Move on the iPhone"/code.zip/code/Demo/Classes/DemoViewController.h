//
//  DemoViewController.h
//  Demo
//
//  Created by Keith A Peters on 2/28/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoViewController : UIViewController <UIAccelerometerDelegate>
{
	UIImageView *ball;
	float x;
	float y;
	float vx;
	float vy;
	float bounce;
	CGPoint gravity;
	BOOL dragging;
}

- (void)onTimer;
@end

