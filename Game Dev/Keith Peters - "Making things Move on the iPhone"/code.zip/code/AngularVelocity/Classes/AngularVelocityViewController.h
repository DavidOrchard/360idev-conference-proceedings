//
//  AngularVelocityViewController.h
//  AngularVelocity
//
//  Created by Keith A Peters on 2/25/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AngularVelocityViewController : UIViewController {
	UIImageView *ball;
	float x;
	float y;
	float angle;
	float speed;
}

- (void)onTimer;

@end

