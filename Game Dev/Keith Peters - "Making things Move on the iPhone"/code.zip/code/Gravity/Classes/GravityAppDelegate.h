//
//  GravityAppDelegate.h
//  Gravity
//
//  Created by Keith A Peters on 2/28/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GravityViewController;

@interface GravityAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    GravityViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet GravityViewController *viewController;

@end

