//
//  AccelerationViewController.h
//  Acceleration
//
//  Created by Keith A Peters on 2/26/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccelerationViewController : UIViewController {
	UIImageView *ball;
	float x;
	float y;
	float vx;
	float vy;
	float ax;
	float ay;
}

- (void)onTimer;

@end

