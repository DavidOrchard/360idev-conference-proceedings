//
//  AccelerationAppDelegate.m
//  Acceleration
//
//  Created by Keith A Peters on 2/26/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import "AccelerationAppDelegate.h"
#import "AccelerationViewController.h"

@implementation AccelerationAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
