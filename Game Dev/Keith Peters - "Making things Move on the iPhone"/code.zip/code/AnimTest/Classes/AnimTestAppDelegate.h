//
//  AnimTestAppDelegate.h
//  AnimTest
//
//  Created by Keith A Peters on 3/2/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AnimTestViewController;

@interface AnimTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    AnimTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet AnimTestViewController *viewController;

@end

