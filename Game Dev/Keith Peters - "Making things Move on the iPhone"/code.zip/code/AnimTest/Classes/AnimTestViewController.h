//
//  AnimTestViewController.h
//  AnimTest
//
//  Created by Keith A Peters on 3/2/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimTestViewController : UIViewController {
	UIImageView *runner;
}

@end

