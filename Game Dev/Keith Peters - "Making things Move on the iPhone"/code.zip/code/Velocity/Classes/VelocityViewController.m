//
//  VelocityViewController.m
//  Velocity
//
//  Created by Keith A Peters on 2/25/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import "VelocityViewController.h"

@implementation VelocityViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	x = 50.0;
	y = 50.0;
	vx = 2.0;
	vy = 3.0;
	ball = [[UIImageView alloc] initWithImage:[UIImage	imageNamed:@"ball.png"]];
	[self.view addSubview:ball];
	[NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}

- (void)onTimer
{
	ball.center = CGPointMake(x, y);
	x += vx;
	y += vy;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[ball release];
    [super dealloc];
}

@end
