//
//  VelocityAppDelegate.h
//  Velocity
//
//  Created by Keith A Peters on 2/25/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VelocityViewController;

@interface VelocityAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    VelocityViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet VelocityViewController *viewController;

@end

