//
//  BouncingAppDelegate.h
//  Bouncing
//
//  Created by Keith A Peters on 2/26/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BouncingViewController;

@interface BouncingAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    BouncingViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet BouncingViewController *viewController;

@end

