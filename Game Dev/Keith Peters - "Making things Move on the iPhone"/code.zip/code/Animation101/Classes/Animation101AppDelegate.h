//
//  Animation101AppDelegate.h
//  Animation101
//
//  Created by Keith A Peters on 2/25/09.
//  Copyright BIT-101 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Animation101ViewController;

@interface Animation101AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Animation101ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Animation101ViewController *viewController;

@end

